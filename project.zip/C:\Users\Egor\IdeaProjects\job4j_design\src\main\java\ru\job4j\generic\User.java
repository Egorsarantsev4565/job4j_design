package ru.job4j.generic;

public class User extends Base {
    public User(String id) {
        super(id);
    }

}
