package ru.job4j.generic;

public class Role extends Base {
    public Role(String id) {
        super(id);
    }
}
