# job4j_design
[![Build Status](https://app.travis-ci.com/Egorsarantsev4565/job4j_design.svg?branch=master)](https://app.travis-ci.com/Egorsarantsev4565/job4j_design)
[![codecov](https://codecov.io/gh/Egorsarantsev4565/job4j_design/branch/master/graph/badge.svg?token=J4AGNGYU6V)](https://codecov.io/gh/Egorsarantsev4565/job4j_design)